<?php
// Database connection
$servername = "localhost";
$username = "root"; // Replace with your MySQL username
$password = ""; // Replace with your MySQL password
$dbname = "aichatbot_database";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$email = $_POST['email'];
$userpassword = $_POST['userpassword'];

// Query the database
$sql = "SELECT * FROM registration WHERE EmailAddress = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    // Verify password (use password hashing for better security)
    if (password_verify($userpassword, $row['Password'])) {
        header("location: chatting.html");
    } else {
        echo "<script language ='javascript'>";
        echo "alert('Wrong username/password!!')";
        echo "</script>";
    }
} else {
    echo "<script language ='javascript'>";
        echo "alert('Email not found, please register!!')";
        echo "</script>";
}

$stmt->close();
$conn->close();
?>

