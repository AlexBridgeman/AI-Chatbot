<?php
// Database connection
$servername = "localhost";
$username = "root"; // Default user for XAMPP/WAMP
$password = ""; // Default password for XAMPP/WAMP
$dbname = "aichatbot_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Capture form data
$name = $_POST['name'];
$email = $_POST['email'];
$userpassword = $_POST['password'];
$confirm_password = $_POST['confirm_password'];

// Check if password and confirm password match
if ($userpassword !== $confirm_password) {
    die("Error: Password and Confirm Password do not match.");
}

// Hash the password for security
$hashed_password = password_hash($userpassword, PASSWORD_DEFAULT);

// Insert data into the database
$sql = "INSERT INTO registration (Name, EmailAddress, Password) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $name, $email, $hashed_password);

if ($stmt->execute()) {
    // Redirect to login.html after successful registration
    header("Location: login.html");
    exit(); // Ensure no further code is executed
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close connection
$stmt->close();
$conn->close();
?>
